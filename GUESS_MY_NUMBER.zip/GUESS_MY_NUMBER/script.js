'use strict';
/*console.log(document.querySelector(".message").textContent);  this query selector will select the query what we have metioned the class name or etc.. and .textcontent will display only the content not any tags
document.querySelector(".message").textContent='Correct NUmber';here we are chaging the content from start guessing to the correct number this is the dom manipulation
console.log(document.querySelector(".message").textContent);
document.querySelector('.number').textContent=13;
document.querySelector('.score').textContent=10;

document.querySelector('.guess').value=23;  //here the value is set to 23
console.log(document.querySelector('.guess').value); */

//handling click events

let Secretnumber=Math.trunc(Math.random()*20)+1;

let Score=20;
let highscore=0;

document.querySelector('.check').addEventListener('click',function(){
    const guess=Number(document.querySelector('.guess').value);
    console.log(guess);
    // document.querySelector(".message").textContent='Correct Number';
//when there is no input
if(!guess){
    document.querySelector(".message").textContent='No Number'
}
//when the numbers matches
else if(guess===Secretnumber){
    document.querySelector('.message').textContent="successfull you won ";
    document.querySelector('.number').textContent=Secretnumber;
    //here we want to manipulate the CSS styles using JS
    document.querySelector('body').style.backgroundColor='green';
    //here changing the width of the number of what we are guessing
    document.querySelector('.number').style.width='30rem';

    if(Score>highscore){
        highscore=Score;
        document.querySelector('.highscore').textContent=highscore;
    }
}
//by refactoring that to reduce the repeated code we have used the ternary operator
else if(guess!==Secretnumber){
    if(Score>1){
        document.querySelector('.message').textContent=(guess>Secretnumber)?"Guess is high":"Guess is Low";
        Score--;
        document.querySelector('.score').textContent=Score;
        }
        else{
            document.querySelector('.message').textContent="You lost the game"
        }
    
}
//when guess is too low
// else if(guess<Secretnumber){
//     if(Score>0){
//     document.querySelector('.message').textContent="Guess is low";
//     Score--;
//     document.querySelector('.score').textContent=Score;
//     }
//     else{
//         document.querySelector('.message').textContent="You lost the game"
//     }
// }


// //when guess is too high
// else if(guess>Secretnumber){
//     if(Score>1){
//     document.querySelector('.message').textContent="Guess is high";
//     Score--;
//     document.querySelector('.score').textContent=Score;
//     }
//     else{
//         document.querySelector('.message').textContent="You lost the game"
//     }
// }


})
//function for again button
document.querySelector('.again').addEventListener('click',function(){
    //restoring the initial values of scores and secretnumber variables
    Score=20;
    Secretnumber=Math.trunc(Math.random()*20)+1;
//restoring the initial conditions of message,number ,score and guess
    document.querySelector('.message').textContent="Start guessing...";
    document.querySelector('.number').textContent='?';
    document.querySelector('.score').textContent=Score;
    document.querySelector('.guess').value='';
//restoring original bg color and width of guess number
    document.querySelector('body').style.backgroundColor='#222';
    document.querySelector('.number').style.width='15rem';

})
