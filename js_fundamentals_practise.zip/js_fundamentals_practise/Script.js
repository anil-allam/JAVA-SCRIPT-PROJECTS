//strict mode: It helps the user to find the errors easily
'use strict';

// let hasdrivinglicense=false;
// const passtest=true;
// if(passtest) hasdrivinglicense=true;
// //if(passtest) hasdrivinglicenses=true;  
// // here we wrote the names as wrong.so,use strict says that that hasdrivinglicenses is not defined.
// if(hasdrivinglicense) console.log("i can drive");

// template literal symbol: [``]

// let js = "helloworld";
// console.log("jairam");

// function fruitProcessor(apples,oranges){
//     const juice='juice with ${apples} apples and ${oranges} oranges';
//     return juice;
// }
// const applejuice=fruitProcessor(5,4);
// console.log(applejuice);

//Arrow functions
// const age = birthyear=>2022-birthyear;
// console.log(age(1992));

// const ageuntilretirement=birthyear=>{
//     const age=2022-birthyear;
//     const retirement=65-age;
//     return retirement;
// }

// console.log(ageuntilretirement(1990));

//task on functions and arrow functions
// const calcAverage = (a, b, c) => (a + b + c) / 3;
// // console.log(calcAverage(3, 4, 5));
 
// let scoreDolphins = calcAverage(44, 23, 71);
// let scoreKoalas = calcAverage(65, 54, 49);
// console.log(scoreDolphins, scoreKoalas);
 
// const checkWinner = function (avgDolphins, avgKoalas) {
//   if (avgDolphins >= 2 * avgKoalas) {
//     console.log(`Dolphins win (${avgDolphins} vs. ${avgKoalas})`);
//   } else if (avgKoalas >= 2 * avgDolphins) {
//     console.log(`Koalas win (${avgKoalas} vs. ${avgDolphins})`);
//   } else {
//     console.log('No team wins...');
//   }
// };
 
// checkWinner(scoreDolphins, scoreKoalas);

//Arrays concept
// const friends=['a','v','f'];
// console.log(friends.length);
// const years=new Array(1990,2000,1200);
// console.log(years[0]);

// const calcage=function(birthyear){
//     return 2022-birthyear;
// }
// const year =[1990,2000,1980];
// console.log(calcage(year[1]));

// const fri=['ram','sita','suresh'];
// fri.push('jay');
// console.log(fri);

//exercise

// function calcTip(bill){
//     if(bill>=50 && bill<=300){
//       const total=bill*(15/100);
//       console.log(total);
//     }
//     else{
//         const total=bill*(20/100);
//         console.log(total);
//     }

// }
// console.log(calcTip(310));
// const bills=[125,555,44];
// const tips=[calcTip(bills[0]),calcTip(bills[1]),calcTip(bills[2])];
// console.log(bills,tips);
// // const tips=calcTip();
// // const totals=[bills+tips]
// // console.log(totals);
//one way
// const calcTip = function (bill) {
//     return bill >= 50 && bill <= 300 ? bill * 0.15 : bill * 0.2;
//   }
   
//   const bills = [125, 555, 44];
//   const tips = [calcTip(bills[0]), calcTip(bills[1]), calcTip(bills[2])];
   
//   console.log(bills, tips);

//2nd way
// const calcTip = function (bill) {
//     return bill >= 50 && bill <= 300 ? bill * 0.15 : bill * 0.2;
//   }
   
//   const bills = [125, 555, 44];
//   const tips = [calcTip(bills[0]), calcTip(bills[1]), calcTip(bills[2])];
//   const totals = [bills[0] + tips[0], bills[1] + tips[1], bills[2] + tips[2]];
   
//   console.log(bills, tips, totals);

//objects in js
//objects are same like arrays but in the type of key value pairs
// const jonas={
//     firstname:"anil",
//     lastname:"varma",
//     address:"hyderabad",
//     friends:['michael','siddu','anil']
// }
//objects are called in two ways they are:(.DOT and []Brackets)
// console.log(jonas.firstname);
// console.log(jonas.lastname);
// console.log(jonas['firstname']);
// //prompt is basically to show a pop up window with data to select
// const intrestedIn=prompt('what do you want to kniw abut jonas?choose between firstname,lastname and address');
// console.log(jonas[intrestedIn]);
// //how to add elements using . and []
// jonas.location='India';
// console.log(jonas);
// jonas['linkedin']="anil@123";
// console.log(jonas);

// console.log(`${jonas.firstname} has ${jonas.friends.length} friends,and his bestfriend is called ${jonas.friends[0]}`);


//-->methods in objects 
// const jonas={
//     firstname:"anil",
//     lastname:"varma",
//     birthyear:2002,
//     address:"hyderabad",
//     hasdrivinglicense:true,
//     friends:['michael','siddu','anil'],

//     calcage: function(){
//         return 2022-this.birthyear;
//     }
// }
// console.log(jonas.calcage());

//exercise -BMI on objects and functions

// const mark = {
//     fullName: 'Mark Miller',
//     mass: 78,
//     height: 1.69,
//     calcBMI: function () {
//       this.bmi = this.mass / (this.height * this.height);
//       return this.bmi;
//     }
//   };
   
//   const john = {
//     fullName: 'John Smith',
//     mass: 92,
//     height: 1.95,
//     calcBMI: function () {
//       this.bmi = this.mass / (this.height * this.height);
//       return this.bmi;
//     }
//   };
   
//   mark.calcBMI();
//   john.calcBMI();
   
//   if (mark.bmi > john.bmi) {
//     console.log(`${mark.fullName}'s BMI (${mark.bmi}) is higher than ${john.fullName}'s (${john.bmi})!`)
//   } else if (john.bmi > mark.bmi) {
//     console.log(`${john.fullName}'s BMI (${john.bmi}) is higher than ${mark.fullName}'s (${mark.bmi})!`)
//   }


//loops concept

// const jonas=[
//     "anil",
//     "varma",
//     2002,
//     "hyderabad",
//     true,
//     ['michael','siddu','anil']   
// ]
// for(i=0;i<=5;i++)
// {
//     console.log(jonas[i]);
// }
//copying array elements in other array
// const years=[1991,1993,2000,2002];
// const ages=[];
// for(i=0;i<=years.length;i++){
//     ages.push(2022-years[i]);
// }
// console.log(ages);

// const jonas=[
//         "anil",
//         "varma",
//         2002,
//         "hyderabad",
//         ['michael','siddu','anil']   
// ];
// for(let i=jonas.length-1;i>=0;i--){
//     console.log(i,jonas[i]);
// }

//loop inside the loop
// for(i=0;i<4;i++){
//     console.log(`first loop ${i}`);
// for(j=0;j<4;j++){
//     console.log(`second loop ${j}`);
// }
// }

//while loop
// let i=1;
// while(i<=10){
//     console.log(i);
//     i++;
// } 

//exercise
// const calcTip = function (bill) {
//     return bill >= 50 && bill <= 300 ? bill * 0.15 : bill * 0.2;
//   }
   
   
//   const bills = [22, 295, 176, 440, 37, 105, 10, 1100, 86, 52];
//   const tips = [];
//   const totals = [];
   
//   for (let i = 0; i < bills.length; i++) {
//     const tip = calcTip(bills[i]);
//     tips.push(tip);
//     totals.push(tip + bills[i]);
//   }
   
//   console.log(bills, tips, totals);
   
//   const calcAverage = function (arr) {
//     let sum = 0;
//     for (let i = 0; i < arr.length; i++) {
//       // sum = sum + arr[i];
//       sum += arr[i];
//     }
//     return sum / arr.length;
//   }
   
//   console.log(calcAverage([2, 3, 7]));
//   console.log(calcAverage(totals));
//   console.log(calcAverage(tips));

//max value in an array
// const testarray=[2,4,10,15,-2,7];
// let max=testarray[0];
// for(i=0;i<=testarray.length;i++){
//     if(testarray[i]>max){
//         max=testarray[i];
//     }
// }
// console.log(max);

//DOM and DOM manipulation  **********IMP**********

//document.querySelector(".message");//this queryselector will slects the query that we montioned abpout a particular class line

//they are three types of keyboard events -->1.keydown__when we click the key,2.keyup--when we release the key after press,3.keypress--user presses the key
// document.addEventListener('keydown',function(){
//     console.log("key pressed");
// })

// document.addEventListener('keyup',function(){
//     console.log("key pressed");
// })

//js store **e** as event that says which key u have pressed and this e store the events 
// document.addEventListener('keyup',function(e){
//      console.log(e);
//  })