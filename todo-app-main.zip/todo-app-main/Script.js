// Change of "theme" on click
var button = document.getElementById("change-theme-color");

button.addEventListener("click", () => {
  button.classList.toggle("moon");
  document
    .getElementsByClassName("half-img-container")[0]
    .classList.toggle("image-container-light");
  document
    .getElementsByClassName("total-container")[0]
    .classList.toggle("bg-container-light");
  document
    .getElementsByClassName("input-dark")[0]
    .classList.toggle("input-light");
  document
    .getElementsByClassName("last-container")[0]
    .classList.toggle("light");
  document.getElementById("functions-control").classList.toggle("light");
  let listEls = document.getElementsByTagName("li");
  for (let i = 0; i < listEls.length; i++) {
    listEls[i].classList.toggle("light");
  }
});

//adding new Task
var inputBox = document.getElementById("input-box");
var listContainer = document.getElementById("list");

//code for the input box
function addTask() {
  if (inputBox.value.trim() === "") {
    alert("You must write something");
  } else {
    let li = document.createElement("li");
    li.innerHTML = inputBox.value;
    listContainer.appendChild(li);
    inputBox.value = "";
    let span = document.createElement("span");
    span.innerHTML = "\u00d7";
    li.appendChild(span);
    li.setAttribute("class", "draggable");
    li.setAttribute("draggable", "true");

    var status = document.getElementById("change-theme-color").className;

    console.log(status.split(" "));

    if (status.split(" ")[1] === "moon") {
      li.classList.add("light");

     
    }

    var listItens = document.querySelectorAll(".draggable");

    [].forEach.call(listItens, function (item) {
      addEventsDragAndDrop(item);
    });
  }
  inputBox.value = "";
  updateCountOfElements();
  // saveData();
}

listContainer.addEventListener(
  "click",
  function (e) {
    if (e.target.tagName === "LI") {
      e.target.classList.toggle("checked");
      updateCountOfElements();
      // saveData();
    } else if (e.target.tagName === "SPAN") {
      e.target.parentElement.remove();
      updateCountOfElements();
      // saveData();
    }
  },
  false
);

// function saveData() {
//   localStorage.setItem("data", listContainer.innerHTML);
//   updateCountOfElements();
// }
// function showTask() {
//   listContainer.innerHTML = localStorage.getItem("data");
//   updateCountOfElements();
// }
// showTask();

// Drag and drop functionality
function dragStart(e) {
  this.style.opacity = "0.4";
  dragSrcEl = this;
  e.dataTransfer.effectAllowed = "move";
  e.dataTransfer.setData("text/html", this.innerHTML);
}

function dragEnter(e) {
  this.classList.add("over");
}

function dragLeave(e) {
  e.stopPropagation();
  this.classList.remove("over");
}

function dragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = "move";
  return false;
}

function dragDrop(e) {
  if (dragSrcEl != this) {
    if(dragSrcEl.className.includes("checked") && this.className.includes("checked")){

      dragSrcEl.innerHTML = this.innerHTML;

      this.innerHTML = e.dataTransfer.getData("text/html");

      // this.className = e.dataTransfer.getData("class/html");

      }
  else if(!dragSrcEl.className.includes("checked")&&this.className.includes("checked")){
      dragSrcEl.innerHTML = this.innerHTML;
      this.innerHTML = e.dataTransfer.getData("text/html");
      this.classList.remove("checked");
      dragSrcEl.classList.add("checked");
  }

  else if(dragSrcEl.className.includes("checked") && !this.className.includes("checked")){
      dragSrcEl.innerHTML = this.innerHTML;
      this.innerHTML = e.dataTransfer.getData("text/html");
      this.classList.add("checked");
      dragSrcEl.classList.remove("checked");
  }  
  else{
      dragSrcEl.innerHTML = this.innerHTML;
      this.innerHTML = e.dataTransfer.getData("text/html");
  }
  }
  return false;
}

function dragEnd(e) {
  var listItens = document.querySelectorAll(".draggable");
  [].forEach.call(listItens, function (item) {
    item.classList.remove("over");
  });
  this.style.opacity = "1";
}

function addEventsDragAndDrop(el) {
  el.addEventListener("dragstart", dragStart, false);
  el.addEventListener("dragenter", dragEnter, false);
  el.addEventListener("dragover", dragOver, false);
  el.addEventListener("dragleave", dragLeave, false);
  el.addEventListener("drop", dragDrop, false);
  el.addEventListener("dragend", dragEnd, false);
}

var listItens = document.querySelectorAll(".draggable");
[].forEach.call(listItens, function (item) {
  addEventsDragAndDrop(item);
});

//update the elements count
function updateCountOfElements() {
  var listItems = document.querySelectorAll(".draggable");
  listLength = listItems.length;
  var checkedItems = document.querySelectorAll(".checked");
  checkedList = checkedItems.length;
  let result = listLength - checkedList;
  let results = document.getElementById("count");
  results.innerHTML = result;
}
//function for clear completed
function removeCompleted() {
  var x = document.getElementById("list");
  var checkedItems = document.getElementsByClassName("checked");
  let len = checkedItems.length;
  for (var i = 0; i < len; i++) {
    x.removeChild(checkedItems[0]);
  }
}
//function for All
function allTasks() {
  var listItems = document.querySelectorAll(".draggable");
  var i;
  for (i = 0; i < listItems.length; i++) {
    listItems[i].style.display = "block";
  }
}
//function for Active Tasks
function activeTasks() {
  var listItems = document.querySelectorAll(".draggable");
  var i;
  for (i = 0; i < listItems.length; i++) {
    listItems[i].style.display = "block";
  }
  var checkedItems = document.getElementsByClassName("checked");
  var j;
  for (j = 0; j < checkedItems.length; j++) {
    checkedItems[j].style.display = "none";
  }
}
//function for completed tasks
function completedTasks() {
  var listItems = document.querySelectorAll(".draggable");
  var i;
  for (i = 0; i < listItems.length; i++) {
    listItems[i].style.display = "none";
  }
  var checkedItems = document.getElementsByClassName("checked");
  var j;
  for (j = 0; j < checkedItems.length; j++) {
    checkedItems[j].style.display = "block";
  }
}
